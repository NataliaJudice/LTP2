﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("       < Trabalho de LTP - Natália Judice e Maiara de Souza >   ");
Console.WriteLine("Escolha uma opção");
Console.WriteLine("0-Sair");
Console.WriteLine("1-Some 2 números");
Console.WriteLine("2-Transforma metro em milimetros");
Console.WriteLine("3-Calcular o aumento");
Console.WriteLine("4-Calcular o desconto");
Console.WriteLine("5-Aluguel do carro");
Console.WriteLine("6-Calcular IMC");
Console.WriteLine("7-Tabuada do número informado");
Console.WriteLine("8-Múltiplos de 3 entre 0 e 100");
Console.WriteLine("9-Fatoriais de 1 até 10");
Console.WriteLine("10-Imposto de renda");
Console.WriteLine("11-Advinhar o número");
Console.WriteLine("12-Financiamento do veículo");
Console.WriteLine("13-Aposentadoria");

for (int i = 0; i < 13; i++)
{
    int opcoes;
    opcoes = int.Parse(Console.ReadLine());
    if (opcoes == 0)
    {
        Sair();
    }
    else if (opcoes == 1)
    {
        Soma();
    }
    else if (opcoes == 2)
    {
        Transformar();
    }
    else if (opcoes == 3)
    {
        Aumento();
    }
    else if (opcoes == 4)
    {
        Desconto();
    }
    else if (opcoes == 5)
    {
        AluguelCarro();
    }
    else if (opcoes == 6)
    {
        CalculoIMC();
    }
    else if (opcoes == 7)
    {
        Tabuada();
    }
    else if (opcoes == 8)
    {
        MultiplosTres();
    }
    else if (opcoes == 9)
    {
        FatoriaisDez();
    }
    else if (opcoes == 10)
    {
        ImpostoDeRenda();
    }
    else if (opcoes == 11)
    {
        Advinhe();
    }
    else if (opcoes == 12)
    {
        Financiamento();
    }
    else if (opcoes == 13)
    {
        Aposentadoria();
    }


    void Sair()
    {
        Environment.Exit(0);
    }

    void Soma()
    {
        float[] num = new float[2];
        float soma;
        soma = 0;
        for (int i = 0; i < 2; i++)
        {
            Console.WriteLine($"Digite o {i + 1} numero");
            num[i] = float.Parse(Console.ReadLine());
        }
        foreach (var n in num)
        {
            soma += n;
        }
        Console.WriteLine($"A soma é {soma}");
    }

    void Transformar()
    {
        float metro;
        float mill;
        Console.WriteLine(" Digite um valor em metro");
        metro = float.Parse(Console.ReadLine());
        mill = metro * 1000;
        Console.WriteLine($"O valor em milimetros é {mill}mm");
    }

    void Aumento()
    {
        decimal salario;
        decimal aumento;
        decimal valoraumento;
        decimal resultado;
        resultado = 0;
        valoraumento = 0;
        Console.WriteLine("Digite o valor atual do salario");
        salario = decimal.Parse(Console.ReadLine());
        Console.WriteLine("Digite quantos % ele vai aumentar");
        aumento = decimal.Parse(Console.ReadLine());
        valoraumento = salario * (aumento / 100);
        resultado = salario + valoraumento;

        Console.WriteLine($"O salário inicial era {salario}");
        Console.WriteLine($"O percentual de aumento foi {aumento}%");
        Console.WriteLine($"O valor do aumento foi {valoraumento}");
        Console.WriteLine($"O salário final é {resultado}");
    }

    void Desconto()
    {
        decimal valorin;
        decimal desconto;
        decimal valordesconto;
        decimal resultado;
        resultado = 0;
        valordesconto = 0;
        Console.WriteLine("Digite o valor atual do salario");
        valorin = decimal.Parse(Console.ReadLine());
        Console.WriteLine("Digite quantos % ele vai diminuir");
        desconto = decimal.Parse(Console.ReadLine());
        valordesconto = valorin * (desconto / 100);
        resultado = valorin - valordesconto;

        Console.WriteLine($"Valor inicial era {valorin}");
        Console.WriteLine($"O percentual de desconto é {desconto}%");
        Console.WriteLine($"O valor do desconto é {valordesconto}");
        Console.WriteLine($"O salário final é {resultado}");
    }

    void AluguelCarro()
    {
        double dias;
        double kmi;
        double kmf;
        double totalkm;
        double totalaluguel;
        double valorpdia;
        double valorpkm;

        totalkm = 0;
        totalaluguel = 0;
        Console.WriteLine("Informe quantos dias o carro foi usado");
        dias = double.Parse(Console.ReadLine());
        Console.WriteLine("Informe a quilometragem inicial");
        kmi = double.Parse(Console.ReadLine());
        Console.WriteLine("Informe a quilometragem final");
        kmf = double.Parse(Console.ReadLine());

        totalkm = kmf - kmi;
        valorpkm = totalkm * 0.35;
        valorpdia = dias * 95;
        totalaluguel = valorpkm + valorpdia;

        Console.WriteLine($"O valor do aluguel é {totalaluguel}");






    }

    void CalculoIMC()
    {
        float altura;
        float peso;
        float IMC;
        IMC = 0;
        Console.WriteLine("Informe sua altura em metros");
        altura = float.Parse(Console.ReadLine());
        Console.WriteLine("Informe seu peso em kg");
        peso = float.Parse(Console.ReadLine());
        IMC = (peso / (altura * altura)) * 1000;

        if (IMC <= 18.5)
        {
            Console.WriteLine($"Seu imc é {IMC}");
            Console.WriteLine("Você está abaixo do peso!");
        }
        else if ((18.6 <= IMC) && (IMC <= 24.9))
        {
            Console.WriteLine($"Seu imc é {IMC}");
            Console.WriteLine("Peso ideal!");
        }
        else if ((IMC <= 25) && (IMC <= 29.9))
        {
            Console.WriteLine($"Seu imc é {IMC}");
            Console.WriteLine("Levemente acima do peso");
        }
        else if ((IMC <= 30) && (IMC <= 34.9))
        {
            Console.WriteLine($"Seu imc é {IMC}");
            Console.WriteLine("Obesidade grau 1");
        }
        else if ((IMC <= 35) && (IMC <= 39.9))
        {
            Console.WriteLine($"Seu imc é {IMC}");
            Console.WriteLine("Obesidade grau 2 (severa)");
        }
        else if (IMC >= 40)
        {
            Console.WriteLine($"Seu imc é {IMC}");
            Console.WriteLine("Obesidade grau 3 (mórbida)");
        }



    }

    void Tabuada()
    {
        float n;
        float resultado;
        resultado = 0;
        Console.WriteLine("Informe um número para fazer a tabuada");
        n = float.Parse(Console.ReadLine());

        for (int cont = 0; cont < 10; cont++)
        {
            resultado = n * cont;
            Console.WriteLine($"{n}x{cont} = {resultado}");
        }
    }

    void MultiplosTres()
    {
        for (int i = 0; i < 100; i++)
        {
            if (i % 3 == 0)
            {
                Console.WriteLine(i);
            }
        }
    }

    void FatoriaisDez()
    {
        float n;
        n = 1;
        for (int i = 1; i <= 10; i++)
        {
            n *= i;
            Console.WriteLine($"O fatorial de {i} é {n}");
        }
    }

    void ImpostoDeRenda()
    {
        double renda;
        double imposto;
        double impcem;
        double impostofinal;
        double dependentes;
        Console.WriteLine("Informe sua renda");
        renda = double.Parse(Console.ReadLine());
        Console.WriteLine("Informe quantos dependentes você possui");
        dependentes = double.Parse(Console.ReadLine());

        if (renda < 1903.99)
        {
            Console.WriteLine("isento!!");
        }
        else if ((renda <= 1903.99) && (renda <= 2826.65))
        {
            imposto = renda* 7.5 ;
            impcem = imposto / 100;
            impostofinal = impcem - 142.80;
            Console.WriteLine($"O valor do seu imposto de renda é {impostofinal}");
        }
        else if ((renda <= 2826.66) && (renda <= 3751.05))
        {
            imposto = renda * 15 ;
            impcem = imposto / 100;
            impostofinal = impcem - 354.80;
            Console.WriteLine($"O valor do seu imposto de renda é {impostofinal}");
        }
        else if ((renda <= 3751.06) && (renda <= 4664.68))
        {
            imposto = renda * 22.5 ;
            impcem = imposto / 100;
            impostofinal = impcem - 636.13;
            Console.WriteLine($"O valor do seu imposto de renda é {impostofinal}");

        }
        else if (renda > 4664.68)
        {
            imposto = renda * 27.5;
            impcem = imposto / 100;
            impostofinal = impcem - 869.36;
            Console.WriteLine($"O valor do seu imposto de renda é {impostofinal}");
        }
    }

    void Advinhe()
    {
        int tentativa;
        Random num = new Random();
        int resposta = num.Next(0, 100);
        Console.WriteLine("Você tem 10 chances para acertar o número");
        Console.WriteLine("(Dica: é um número inteiro entre 0 e 100)");
        for (int i = 1; i < 10; i++)
        {
            Console.WriteLine($"{i} tentativa");
            tentativa = int.Parse(Console.ReadLine());
            if (tentativa == resposta)
            {
                Console.WriteLine("Você acertou!");
            }
            else
            {
                Console.WriteLine("Número errado,tente novamente");
            }
        }
        Console.WriteLine($"O número era {resposta}");
    }

    void Financiamento()
    {
        double valorVeiculo;
        int totalParcelas;
        double taxaAdminin;
        double totalAdmin;
        double taxaJuros;
        double parcelaEstimada;
        double totalCarro;
        double ju = 0;


        totalCarro = 0;

        Console.WriteLine("Informe o valor do veículo");
        valorVeiculo = double.Parse(Console.ReadLine());
        Console.WriteLine("Informe em quantas parcelas voce irá pagar");
        totalParcelas = int.Parse(Console.ReadLine());
        Console.WriteLine("Informe a taxa de juros");
        taxaJuros = double.Parse(Console.ReadLine());



        if (taxaJuros == 0)
        {
            Console.WriteLine("Qual a taxa administrativa?");
            taxaAdminin = double.Parse(Console.ReadLine());
            parcelaEstimada = valorVeiculo / totalParcelas;
            totalAdmin = taxaAdminin / totalParcelas;
            totalAdmin = (totalAdmin * valorVeiculo) / 100;
            totalCarro = (totalAdmin + parcelaEstimada) * totalParcelas;

            Console.WriteLine($"O valor total a ser pago é {totalCarro}");
        }
        else
        {
            ju = (1 + taxaJuros);
            double a = Math.Pow(ju, totalParcelas);
            totalCarro = valorVeiculo * a;
            Console.WriteLine(totalCarro);


        }

    }

    void Aposentadoria()
    {
        int anos;
        int pretende;
        double guardar;
        double taxa;
        double resul;
        double mens;
        double totalA;
        
        Console.WriteLine("Quantos anos você tem?");
        anos = int.Parse(Console.ReadLine());
        Console.WriteLine("Com quantos anos você pretende se aposentar?");
        pretende = int.Parse(Console.ReadLine());
        Console.WriteLine("Quanto você pretende guardar mensalmente?");
        guardar = double.Parse(Console.ReadLine());
        Console.WriteLine("Qual a taxa de rendimento mensal?");
        taxa = double.Parse(Console.ReadLine());

        totalA = pretende - anos;
        resul = (guardar * (taxa/100)) * totalA;
        mens = guardar * (taxa / 100);

        Console.WriteLine($"O montante final será {resul}");
        Console.WriteLine($"Sua renda mensal será {mens}");

    }


}

