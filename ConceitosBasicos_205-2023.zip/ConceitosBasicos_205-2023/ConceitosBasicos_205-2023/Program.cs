﻿// See https://aka.ms/new-console-template for more information
using System.Net.Http.Headers;

byte[] idades = new byte[5];
byte resultado;
byte menoridade;
byte maioridade;
 menoridade = idades[0];
 maioridade = idades[0];
resultado = 0;

LerIdades();

Mostrar();

Menor();

Maior();

Media();

Par();

Impar();


void Mostrar()
{
    Console.WriteLine("As idades informadas foram");
    foreach (var idade in idades)
    {
        Console.WriteLine(idade);
    }
}

void LerIdades()
{
    for (int i = 0; i < 5; i++)
    {
        Console.WriteLine($"Informe a {i + 1} idade");
        idades[i] = byte.Parse(Console.ReadLine());
    }
}


void Menor()
{
    foreach (var idade in idades)
    {
        if (idade < menoridade)
        {
            menoridade = idade;
        }
    }
    Console.WriteLine($"A menor idade é {menoridade}");
}

void Maior()
{
    foreach (var idade in idades)
    {
        if (idade > maioridade)
        {
            maioridade = idade;
        }
    }
    Console.WriteLine($"A maior idade é {maioridade}");
}

void Media()
{
    foreach (var idade in idades)
    {
        resultado += idade;
    }
    resultado /= 5;
    Console.WriteLine($"A média das as idades informadas é {resultado}");
}

void Par()
{
    Console.WriteLine("As idades pares são:");
    foreach (var idade in idades)
    {
        if (idade % 2 == 0)
        {
            Console.WriteLine(idade);
        }
    }
}

void Impar()
{
    Console.WriteLine("As idades ímpares são:");
    foreach (var idade in idades)
    {
        if (idade % 2 != 0)
        {
            Console.WriteLine(idade);
        }
    }
}